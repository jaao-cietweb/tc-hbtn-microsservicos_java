package com.example.MegaSenaAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MegaSenaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MegaSenaApiApplication.class, args);
	}

}
